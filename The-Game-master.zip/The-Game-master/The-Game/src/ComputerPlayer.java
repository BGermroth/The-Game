
public class ComputerPlayer extends Player 
{
	
	public ComputerPlayer(boolean teamRed)
	{
		super(teamRed);
	}
}
